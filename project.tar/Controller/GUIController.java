package Controller;

public interface GUIController {

}
