package Entity;

public interface Observer {
    public void update(Property p);
}
